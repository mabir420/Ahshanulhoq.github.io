MAHA Portfolio PWA starter package

Included:
- index.html: updated with PWA metadata and Service Worker registration; original layout mostly preserved.
- about.html: added PWA metadata and Service Worker registration.
- manifest.json
- sw.js
- offline.html
- icons/icon-192.png and icons/icon-512.png

Deployment:
1. Back up the current website first.
2. Upload these files to the same root folder as the site's current index.html (usually public_html).
3. Upload the icons folder with both PNG files.
4. Do not overwrite style.css, script.js, images, or other pages.
5. Test https://ahshanulhoq.com/manifest.json and https://ahshanulhoq.com/sw.js.
6. Test installation and offline behavior on Android Chrome.

Notes:
- This is a starter PWA package, not a complete replacement of all website files.
- Only index.html and about.html were supplied for modification.
- Push notifications and a secure admin dashboard are not included yet.
- The Service Worker caches the home page and same-origin assets as they are visited. Offline availability is limited to cached pages/assets.
- If your hosting uses a different document root or URL routing, adjust paths accordingly.
